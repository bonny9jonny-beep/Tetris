# FSociety Tetris (Rust)

Termux:
    pkg update && pkg install rust unzip
    unzip fsociety-tetris.zip && cd fsociety-tetris
    cargo run --release          # порт 8080
    cargo run --release -- 9000  # другой порт
Открой http://localhost:8080 в браузере телефона.
