'use strict';
const $ = i => document.getElementById(i);
const cv = $('game'), g = cv.getContext('2d'), nv = $('next'), n2 = nv.getContext('2d'), bg = $('bg'), b = bg.getContext('2d');
const W = 10, H = 20, S = 30;
const COL = ['#00e5ff', '#ffd400', '#ff2e88', '#3d6bff', '#ff7a1a', '#35ff8c', '#ff3b3b'];
const SH = [[[1,1,1,1]], [[1,1],[1,1]], [[0,1,0],[1,1,1]], [[1,0,0],[1,1,1]], [[0,0,1],[1,1,1]], [[0,1,1],[1,1,0]], [[1,1,0],[0,1,1]]];
let board, p, nxt, bag = [], score, level, lines, over, drop, acc, parts = [], shake = 0, flash = [], flashT = 0, best = 0;
try { best = +localStorage.getItem('fsb') || 0 } catch {}

// звук: синтез на лету, без файлов
let ac;
function tone(f, d, t = 'square', v = .05, e = f) {
  try {
    ac = ac || new (window.AudioContext || webkitAudioContext)();
    const o = ac.createOscillator(), a = ac.createGain(), n = ac.currentTime;
    o.type = t; o.frequency.setValueAtTime(f, n); o.frequency.exponentialRampToValueAtTime(e, n + d);
    a.gain.setValueAtTime(v, n); a.gain.exponentialRampToValueAtTime(.001, n + d);
    o.connect(a).connect(ac.destination); o.start(); o.stop(n + d);
  } catch {}
}
const vib = ms => { try { navigator.vibrate && navigator.vibrate(ms) } catch {} };

function take() {
  if (!bag.length) { bag = [0,1,2,3,4,5,6]; for (let i = 6; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [bag[i], bag[j]] = [bag[j], bag[i]] } }
  return bag.pop();
}
function hit(dx, dy, s = p.s) {
  for (let r = 0; r < s.length; r++) for (let c = 0; c < s[r].length; c++) {
    if (!s[r][c]) continue;
    const x = p.x + c + dx, y = p.y + r + dy;
    if (x < 0 || x >= W || y >= H || (y >= 0 && board[y][x])) return true;
  }
  return false;
}
function spawn() {
  p = { i: nxt, s: SH[nxt], x: 0, y: 0 };
  p.x = (W - p.s[0].length) >> 1;
  nxt = take(); drawNext();
  if (hit(0, 0)) end();
}
function burst(x, y, c, n, v) {
  for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, s = Math.random() * v + 1; parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 1, l: 1, c }) }
}
function glitch() { cv.classList.remove('glitch'); void cv.offsetWidth; cv.classList.add('glitch') }

function lock() {
  p.s.forEach((row, r) => row.forEach((v, c) => {
    if (!v) return;
    const y = p.y + r, x = p.x + c;
    if (y >= 0) board[y][x] = p.i + 1;
    burst(x * S + S / 2, y * S + S / 2, COL[p.i], 2, 2.5);
  }));
  tone(130, .12, 'sawtooth', .06, 50);
  const cl = []; for (let y = 0; y < H; y++) if (board[y].every(v => v)) cl.push(y);
  if (cl.length) {
    cl.forEach(y => { for (let x = 0; x < W; x++) burst(x * S + S / 2, y * S + S / 2, COL[board[y][x] - 1], 3, 6) });
    board = board.filter((_, y) => !cl.includes(y));
    while (board.length < H) board.unshift(Array(W).fill(0));
    lines += cl.length; score += [0, 100, 300, 500, 800][cl.length] * level;
    level = 1 + (lines / 10 | 0); drop = Math.max(90, 700 - (level - 1) * 55);
    flash = cl; flashT = 1; shake = cl.length === 4 ? 24 : 5 + cl.length * 3; glitch(); vib(cl.length * 25);
    tone(300, .35, 'square', .06, 1400); if (cl.length === 4) setTimeout(() => tone(500, .4, 'sawtooth', .06, 2000), 120);
    hud();
  }
  spawn();
}
function mv(dx) { if (!over && !hit(dx, 0)) { p.x += dx; tone(220, .03, 'square', .03) } }
function soft() { if (over) return; if (!hit(0, 1)) { p.y++; score++; hud() } else lock(); acc = 0 }
function hard() {
  if (over) return; let n = 0;
  while (!hit(0, 1)) { p.y++; n++ }
  score += n * 2; shake = 7; tone(200, .15, 'sawtooth', .07, 40); vib(12);
  p.s[p.s.length - 1].forEach((v, c) => v && burst((p.x + c) * S + S / 2, (p.y + p.s.length) * S, COL[p.i], 5, 4));
  lock(); hud(); acc = 0;
}
function turn() {
  if (over) return; const s = p.s, h = s.length, w = s[0].length;
  const n = Array.from({ length: w }, (_, c) => Array.from({ length: h }, (_, r) => s[h - 1 - r][c]));
  for (const k of [0, -1, 1, -2, 2]) if (!hit(k, 0, n)) { p.s = n; p.x += k; tone(440, .08, 'square', .04, 700); return }
}
function end() {
  over = true; shake = 26; glitch(); vib(200); tone(400, .9, 'sawtooth', .07, 40);
  if (score > best) { best = score; try { localStorage.setItem('fsb', best) } catch {} }
  $('final').textContent = `Счёт ${score}, рекорд ${best}`; $('over').hidden = false; hud();
}
function reset() {
  board = Array.from({ length: H }, () => Array(W).fill(0));
  score = 0; level = 1; lines = 0; drop = 700; acc = 0; over = false; parts = []; flash = [];
  $('over').hidden = true; nxt = take(); spawn(); hud();
}
function hud() { $('score').textContent = score; $('level').textContent = level; $('lines').textContent = lines; $('best').textContent = Math.max(best, score) }

function cell(c, x, y, a = 1, ctx = g, s = S) {
  ctx.globalAlpha = a; ctx.shadowColor = c; ctx.shadowBlur = s / 2.5; ctx.fillStyle = c;
  ctx.fillRect(x + 1, y + 1, s - 2, s - 2); ctx.shadowBlur = 0;
  ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.fillRect(x + 1, y + 1, s - 2, s / 8);
  ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(x + 1, y + s - 1 - s / 8, s - 2, s / 8); ctx.globalAlpha = 1;
}
function drawNext() {
  n2.clearRect(0, 0, 80, 80); const s = SH[nxt], k = 18;
  const ox = (80 - s[0].length * k) / 2, oy = (80 - s.length * k) / 2;
  s.forEach((row, r) => row.forEach((v, c) => v && cell(COL[nxt], ox + c * k, oy + r * k, 1, n2, k)));
}
function render() {
  g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, 300, 600);
  if (shake > .3) g.translate((Math.random() - .5) * shake, (Math.random() - .5) * shake);
  g.strokeStyle = 'rgba(255,255,255,.045)'; g.lineWidth = 1; g.beginPath();
  for (let i = 1; i < W; i++) { g.moveTo(i * S, 0); g.lineTo(i * S, 600) }
  for (let i = 1; i < H; i++) { g.moveTo(0, i * S); g.lineTo(300, i * S) }
  g.stroke();
  board.forEach((row, y) => row.forEach((v, x) => v && cell(COL[v - 1], x * S, y * S)));
  if (!over) {
    let gy = 0; while (!hit(0, gy + 1)) gy++;
    g.strokeStyle = COL[p.i]; g.globalAlpha = .45;
    p.s.forEach((row, r) => row.forEach((v, c) => v && g.strokeRect((p.x + c) * S + 2, (p.y + r + gy) * S + 2, S - 4, S - 4)));
    g.globalAlpha = 1;
    p.s.forEach((row, r) => row.forEach((v, c) => v && cell(COL[p.i], (p.x + c) * S, (p.y + r) * S)));
  }
  parts.forEach(q => { g.globalAlpha = Math.max(0, q.l); g.fillStyle = q.c; g.fillRect(q.x, q.y, 3, 3) }); g.globalAlpha = 1;
  if (flashT > 0) { g.fillStyle = `rgba(255,255,255,${flashT * .85})`; flash.forEach(y => g.fillRect(0, y * S, 300, S)) }
}

// фон: дождь из hex
let cols, rain = [], fr = 0;
function rs() { bg.width = innerWidth; bg.height = innerHeight; cols = Math.ceil(bg.width / 16); rain = Array.from({ length: cols }, () => Math.random() * bg.height / 16) }
addEventListener('resize', rs); rs();
function drawRain() {
  b.fillStyle = 'rgba(9,11,18,.14)'; b.fillRect(0, 0, bg.width, bg.height);
  b.fillStyle = 'rgba(0,229,255,.32)'; b.font = '14px monospace';
  rain.forEach((d, i) => {
    b.fillText('0123456789abcdef'[Math.random() * 16 | 0], i * 16, d * 16);
    rain[i] = d * 16 > bg.height && Math.random() > .975 ? 0 : d + .7;
  });
}

let last = 0;
function loop(t) {
  const dt = Math.min(100, t - last); last = t;
  if (!over) { acc += dt; if (acc >= drop) { acc = 0; soft() } }
  parts.forEach(q => { q.x += q.vx; q.y += q.vy; q.vy += .15; q.l -= dt / 700 });
  parts = parts.filter(q => q.l > 0); shake *= .88; flashT -= dt / 350;
  if (!(fr++ % 3) && !matchMedia('(prefers-reduced-motion:reduce)').matches) drawRain();
  render(); requestAnimationFrame(loop);
}

// управление
const A = { left: () => mv(-1), right: () => mv(1), soft, hard, turn, reset };
document.querySelectorAll('[data-a]').forEach(el => {
  const f = A[el.dataset.a]; let t = 0; const stop = () => { clearInterval(t); t = 0 };
  el.addEventListener('pointerdown', e => { e.preventDefault(); f(); if (el.dataset.r) t = setInterval(f, 95) });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => el.addEventListener(ev, stop));
});
addEventListener('keydown', e => {
  const k = { ArrowLeft: A.left, ArrowRight: A.right, ArrowDown: soft, ArrowUp: turn, ' ': hard, r: reset, R: reset }[e.key];
  if (k) { e.preventDefault(); k() }
});
let sx, sy;
cv.addEventListener('touchstart', e => { e.preventDefault(); sx = e.touches[0].clientX; sy = e.touches[0].clientY }, { passive: false });
cv.addEventListener('touchmove', e => e.preventDefault(), { passive: false });
cv.addEventListener('touchend', e => {
  e.preventDefault(); const dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy, u = cv.clientWidth / W;
  if (Math.abs(dx) < 14 && Math.abs(dy) < 14) turn();
  else if (Math.abs(dx) > Math.abs(dy)) { for (let i = 0, n = Math.round(Math.abs(dx) / u); i < n; i++) mv(Math.sign(dx)) }
  else if (dy > 0) hard(); else turn();
}, { passive: false });

if (window.Telegram?.WebApp) {
  const T = Telegram.WebApp; T.ready(); T.expand(); T.disableVerticalSwipes?.();
  T.MainButton.setText('Перезапуск').show(); T.MainButton.onClick(reset);
}
reset(); requestAnimationFrame(loop);
